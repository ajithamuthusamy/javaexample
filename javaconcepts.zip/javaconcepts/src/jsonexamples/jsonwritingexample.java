package jsonexamples;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class jsonwritingexample {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		JSONObject jsonobject=new JSONObject();
		jsonobject.put("name", "ajitha");
		jsonobject.put("age", 1);
		JSONArray array=new JSONArray();
		array.add("magicalsmile");
		array.add("magneticeyes");
		jsonobject.put("speacialqualities", array);
		FileWriter writer=new FileWriter("ajitha.json");
		writer.write(jsonobject.toJSONString());
		writer.close();

	}

}
