package javaconceptpractice;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class jsonwritingexample {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		JSONObject jsonobject=new JSONObject();
		jsonobject.put("name", "ajitha");
		jsonobject.put("age", 1);
		JSONArray array=new JSONArray();
		array.add("goodnature");
		array.add("goodlooking");
		jsonobject.put("specialqualities", array);
		FileWriter writer=new FileWriter("aji.json");
		writer.write(jsonobject.toJSONString());
		
		writer.close();
		
		

	}

}
