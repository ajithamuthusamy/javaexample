package javaconceptpractice;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class bufferedfilewriterexample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String location="ajitha1.txt";
		String content="i am not in a good mood";
		FileWriter writer=new FileWriter(location);
		BufferedWriter buffered=new BufferedWriter(writer);
		buffered.write(content);
		buffered.close();
		

	}

}
