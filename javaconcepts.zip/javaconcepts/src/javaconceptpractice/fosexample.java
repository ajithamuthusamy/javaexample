package javaconceptpractice;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class fosexample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
String location="ajitha2.txt";
String content="my baby has beautiful eyes";
FileOutputStream stream=new FileOutputStream(location);
byte[] writethis=content.getBytes();
stream.write(writethis);
stream.close();

	}

}
