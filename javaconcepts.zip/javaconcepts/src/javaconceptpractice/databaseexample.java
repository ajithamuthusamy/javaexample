package javaconceptpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class databaseexample {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		// TODO Auto-generated method stub
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection connection=DriverManager.getConnection("jdbc:mysql://root@localhost/database1");
Statement statement=	connection.createStatement();
ResultSet result=statement.executeQuery("SELECT * FROM `names1`" );
while(result.next()) {
	System.out.println("name is:"+result.getString(1)+"nickname is:"+result.getString(2));
}
}

	}


