package javaconceptpractice;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class jsonreadingexample {

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		JSONParser jsonparser=new JSONParser();
		FileReader reader=new FileReader("aji.json");
		
	Object parsedobject=	jsonparser.parse(reader);
	JSONObject jsonobject=(JSONObject) parsedobject;
String name=	(String) jsonobject.get("name");
		long age=(long) jsonobject.get("age");
		System.out.println("name is:"+name+"age is:"+age);
JSONArray jsonarray=	(JSONArray) jsonobject.get("specialqualities");
Iterator iterator=jsonarray.iterator();
while(iterator.hasNext()) {
	System.out.println(iterator.next());
}

	}

}
