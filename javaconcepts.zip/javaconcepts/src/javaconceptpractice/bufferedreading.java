package javaconceptpractice;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class bufferedreading {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader reader=new FileReader("ajitha1.txt");
		BufferedReader buffered=new BufferedReader(reader);
	String currentline=buffered.readLine();
	 
	System.out.println(currentline);
	
		
	}

	}


