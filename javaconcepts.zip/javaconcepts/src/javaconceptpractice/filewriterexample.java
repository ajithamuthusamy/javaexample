package javaconceptpractice;

import java.io.FileWriter;
import java.io.IOException;

public class filewriterexample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String location="ajitha.txt";
		String content="my daughter is my world";
FileWriter filewriter=new FileWriter(location);
filewriter.write(content);
filewriter.close();
	}

}

