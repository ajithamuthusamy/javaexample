
public class swap {
	public static void swapthenumbers() {
		int mysalary=10;
		int supreiorsalary=20;
		int temp=mysalary;
		mysalary=supreiorsalary;
		supreiorsalary=temp;
		System.out.println("xvalue:"+mysalary+"y value:"+supreiorsalary);
	}
	public static void swapwithoutusingthirdvariable() {
		int x=10;
		int y=20;
	/* x=x-y;
	 y=x+y;
	 x=y-x;*/
		/*x=x*y;
		x=x/y;
		x=x/y;*/
		x=x+y;
		y=x-y;
		x=x-y;
		
			 
			 
	
	 
	 System.out.println("x value is:"+x+"y vaslue is:"+y);
		
				
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		swapthenumbers();
		swapwithoutusingthirdvariable();

	}

}
