import java.util.Scanner;

public class triangularpattern {
	public static void stars() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the number of lines:");
	int nooflines=	scanner.nextInt();
	int row,column=0;
	for(row=0;row<nooflines;row++) {
		for(column=0;column<=row;column++) {
			System.out.print("*");
		}
		System.out.println("");
	}
	}
	public  static void numbers() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the number of lines:");
		int startingnumber=1;
		int limit;
	limit=	 scanner.nextInt();
	int row,column;
	for(row=0;row<=limit;row++) {
		for(column=0;column<=row;column++) {
			System.out.print(startingnumber+" ");
			startingnumber=startingnumber+1;
		}
		System.out.println(" ");
	}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//stars();
		numbers();

	}

}
