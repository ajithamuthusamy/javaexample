
public class extractnumberfromstring {

	public static void main(String[] args) {
		String name="ajitha1992";
		int total=0;
	int length=	name.length();
	for(int i=0;i<length;i++) {
	char character=	name.charAt(i);
	if(Character.isDigit(character)) {
	total=total+	Character.getNumericValue(character);
	}
 
	
}
	System.out.println(total);
	String name1="ajitha123";
	System.out.println(name1.replaceAll("[^0-9]", ""));
	}
	
		
	}

