import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

import net.bytebuddy.implementation.FieldAccessor.OwnerTypeLocatable;

public class reversemethods {
	public void stringbufferandbuider() {
		String given="ajitha";
		StringBuilder builder=new StringBuilder();
		builder.append(given);
		System.out.println(builder.reverse());
	}
	public void ownlogic() {
		String given="ajitha";
	char[] array=	given.toCharArray();
	String reversed="";
	for(int i=array.length-1;i>=0;i--) {
		reversed=reversed+array[i];
		
	}
	System.out.println(reversed);
	}
public void ownlogic1() {
	String given="ajitha";
	for(int i=given.length()-1;i<=0;i--) {
		System.out.println(given.charAt(i));
	}
}
	public void reversedName(String reversedName) {
		System.out.println("Received Name" +reversedName);
	}	
	
	
	public void arraylist() {
		String given="ajitha";
	char[] array=given.toCharArray();
	List<Character> list=new ArrayList<Character>();
	for (Character character : array) {
		list.add(character);
	}
	Collections.reverse(list);
		ListIterator iterator=list.listIterator();
		while(iterator.hasNext()) {
		System.out.print(iterator.next());
		
		}

		


		

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
			
	

	public static void main(String[] args) {
		
	reversemethods methods=new reversemethods();
	//methods.stringbufferandbuider();
	//methods.ownlogic();
	//methods.arraylist();
	methods.ownlogic1();
	

	}

}
