import java.util.stream.IntStream;

public class findtheelement {
	static int [] array= {2,3,4,5,7,3,1,3};
	static int numbertofind=1;
	static boolean found=false;
	public static void findnumber() {
		for (int i : array) {
			if(i==numbertofind) {
				found=true;
				break;
				
			
				
			}
			
		}
		System.out.println("number is present:");
		
	}
	public static void usinginstream() {
	boolean found=	IntStream.of(array).anyMatch(element->element==numbertofind);
		if(found) {
			System.out.println("number is present");
		}else {
			System.out.println("not present");
		}
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//findnumber();
		usinginstream();
		

	}

}
