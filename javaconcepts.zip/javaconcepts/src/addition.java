
public class addition {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=5;
		int n2=7;
		
	
		int result= n1+n2;
		System.out.println(result);
		int result1=n1-n2;
		System.out.println(result1);
		
		
		for (int i=0;i<=100;i++) {
			System.out.println(i);
			
			
			
		}
		
		
			for (int i=0;i<=100;i++) {
				if( i%2==0) {
			System.out.println("even number is"+i);
			
		}
		}
			for (int j=0;j>=100;j++) {
				if( j%2==1) {
			System.out.println("addnumber is:"+j);
			
		}
		
	/*	int j=1;
		while(j<=100) {
			System.out.println(j);
			j++;
		}
	}
	
	int k=1;
	do {
		System.out.println(k);
		k++;
	}
	while(k<=100);
	*/
	}

	}
}
