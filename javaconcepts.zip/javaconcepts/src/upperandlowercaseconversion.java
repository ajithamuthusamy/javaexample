
public class upperandlowercaseconversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="I AM DHANYA";
	char[] inputarray=	input.toCharArray();
	for (int i=0;i<inputarray.length;i++) {
		if(inputarray[i]>=65&&inputarray[i]<=90) {
			inputarray[i]=(char) (inputarray[i]+32);
		}
		
		
		
	}
	for (int i=0;i<inputarray.length;i++)
System.out.print(inputarray[i]);
	}

}
