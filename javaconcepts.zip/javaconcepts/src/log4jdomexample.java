import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class log4jdomexample {
	
static Logger logger=Logger.getLogger(log4jdomexample.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DOMConfigurator.configure("log4jexample.xml");
		logger.debug("this is the debugmessage");
		logger.info("this is the info message");
		logger.warn("this is the warning message");
		logger.error("this is the error");
		logger.fatal("this is the fatal");
		

	}

}
