
public class occuranceofachar {

	public static void main(String[] args) {
		//usingiteration
	/*	String input="ajitha";
		char tofind='a';
		int occurance=0;
		input=input.toUpperCase();
tofind=Character.toUpperCase(tofind);
		System.out.println(input);
		for (int i=0;i<input.length();i++) {
			if(input.charAt(i)==tofind) {
			occurance=	occurance+1;
			}
						
		}
		System.out.println(occurance);
		

	}

}*/
		//withoutiteration
		String input="dhanya";
		char tofind='a';
	input=	input.toUpperCase();
String chartofind=	Character.toString(tofind).toUpperCase();
int actuallength=input.length();
System.out.println(actuallength);
input=input.replace(chartofind, "");
System.out.println(input);
int lengthafterreplacing=input.length();
System.out.println(lengthafterreplacing);
System.out.println(actuallength-lengthafterreplacing);
	}
} 
		
