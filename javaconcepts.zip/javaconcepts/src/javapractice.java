import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class javapractice {
	public void howtoreverseastring() {
		String name="ajitha";
		/*StringBuffer buffer=new StringBuffer();
		buffer.append(name);
		System.out.println(buffer.reverse());*/
		String reversed="";
	char[] namearray=	name.toCharArray();
	//for (char c : namearray) {
	for(int i=namearray.length-1;i>=0;i--) {
	reversed=reversed+namearray[i];

		
	}
	System.out.println(reversed);
	}
	public void usingarraylist() {
		String name="dhanya";
	char[] arrayname=	name.toCharArray();
	List<Character> list=new ArrayList<Character>();
	for (Character character : arrayname) {
		list.add(character);
		
	}
	Collections.reverse(list);
	ListIterator<Character> iterator=list.listIterator();
	while(iterator.hasNext()) {
		System.out.print(iterator.next());
	}
	}
	public void swapthenumbers() {
		/*int mysalary=20;
		int myfriendsalary=50;
		int temp=mysalary;
		mysalary=myfriendsalary;
		myfriendsalary=temp;
		System.out.println("mysalaryis:"+mysalary+"myfriendsalaryis:"+myfriendsalary);*/
		int x=20;
		int y=30;
		x=x+y;
		y=x-y;
		x=x-y;
		System.out.println("x value"+x+"y value"+y);
				
		
	}
	public void reversethenumber() {
		/*int givennumber=123;
		int reversednumber=0;
		while(givennumber!=0) {
			reversednumber=reversednumber*10;
			reversednumber=reversednumber+givennumber%10;
			givennumber=givennumber/10;*/
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter your number:");
		int givennumber=scanner.nextInt();
		int reversednumber=0;
		while(givennumber!=0) {
			reversednumber=reversednumber*10;
			reversednumber=reversednumber+givennumber%10;
			givennumber=givennumber/10;
			
		}
		System.out.println(reversednumber);
	}
	public void triangularpattern() {
		//Scanner scanner=new Scanner(System.in);
		//System.out.println("enter the number of lines:");
		//int number=scanner.nextInt();
		
		int number = 9;
		int row,column=0;
		for (row=0;row<=number;row++) {
			for(column=0;column<=row;column++) {
			System.out.print("*");	
				
				
			}
			System.out.println("");

			
		}
			}
	public void findthelengthofthestring() {
		String given="i am mother of my daughter";
		given=given.replaceAll(" ","");
	char[] givenarray=	given.toCharArray();
	System.out.println(givenarray);
	int length=0;
	for (char c : givenarray) {
		length=length+1;
	}
		System.out.println(length);
	}
		
	public void smallestnumber() {
		int givennumber[]= {10,2,3,5,7,9};
		/*int smallest=Integer.MAX_VALUE;
	for (int i=0;i<givennumber.length;i++) {
		if(givennumber[i]<smallest) {
		smallest=givennumber[i];
		
		
	}
			
		}

	System.out.println(smallest);
	
	}*/
		/*Arrays.sort(givennumber);
		System.out.println(givennumber[0]);*/
		List<int[]> list=Arrays.asList(givennumber);
		Collections.sort(list);
	System.out.println(	list.get(0));
	}
	public void reverseawords() {
		String given="i love my baby";
	String[] given1=	given.split(" ");
	System.out.println(given1);
	String reversed=" ";
	for (int i =given1.length-1;i>=0;i--) {
		reversed=reversed+given1[i]+" ";
		
	}
	System.out.println(reversed);
	}
public void elementpresentinthearray() {
	int[] given={2,7,4,5,3,7};
	int tofind=3;
	boolean found=false;
	for(int i=0;i<given.length;i++) {
		if(given[i]==tofind) {
			found=true;
			break;
			
		}
	}
	if(found) {
	System.out.println("the number is present");
	}else {
		System.out.println("the number is not present");
	}
}
	public void positionofanenglishalphabet() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the character:");
char givenchar=		scanner.next().charAt(0);
givenchar=Character.toLowerCase(givenchar);
int asciivalue=(int)givenchar;
System.out.println(asciivalue);
int position=asciivalue-96;
System.out.println(position);
	}
public void findtheoccuranceofacharactewrfromastring() {
	String given="ajitha";
	//char[] given1=given.toCharArray();
	char tofind='a';
	given=given.toLowerCase();
String	tofind1=Character.toString(tofind).toLowerCase();
int fulllength=tofind1.length();
String given2=tofind1.replace(tofind1, "");
int length=given2.length();
int actuallength=fulllength-length;
System.out.println(actuallength);
	
}
	/*int occurance=0;
	for(int i=0;i<given1.length;i++) {
		if(given1[i]==tofind) {
			occurance=occurance+1;	
		}
	}
	System.out.println(occurance);	
	
}*/
public void removetheleadingandtrailingedge() {
	String given= "ajitha" ;
	System.out.println(given.trim());
	System.out.println(given.replaceAll("^[\t]+|[\t]+$",""));	
}
public void findthemissingalphabetinthegivenstring() {
	String given="a";
	String[] givenarray=given.split("");
	String[] alphabets="abcdefghijklmnopqrstuvwxyz".split("");
	//for(int i=0;i>givenarray.length;i++) {
		HashSet<String> set=new HashSet<String>(Arrays.asList(givenarray));
		HashSet<String> set1=new HashSet<String>(Arrays.asList(alphabets));
		set1.removeAll(set);
		System.out.println(set1);	
	}
public void numberofvowelsinyourname() {
	String given="ajitha";
given=	given.toLowerCase();
int vowels=0;
for(int i=0;i<given.length();i++) {
	
if(given.charAt(i)=='a'||given.charAt(i)=='e'||given.charAt(i)=='i'||given.charAt(i)=='o'||given.charAt(i)=='u') {
	vowels=vowels+1;	
}
		
	}
System.out.println(vowels);
}
public void extractnumbersfromastringandaddthem() {
	String given="dhanya1234";
	int total=0;
	for(int i=0;i<given.length();i++) {
char character=	given.charAt(i);
if(Character.isDigit(character)) {
total=total+Character.getNumericValue(character);
}
	}
	System.out.println(total);
	
}
public void replacevowelswithasprecialcharacter() {
	String given="i am ajitha";
	given=given.toLowerCase();
	char[] givenarray=given.toCharArray();
	for(int i=0;i<given.length();i++) {
		if(given.charAt(i)=='a'||given.charAt(i)=='e'||given.charAt(i)=='i'||given.charAt(i)=='o'||given.charAt(i)=='u') {
			
			givenarray[i]='*';
		}
	}
	for(int i=0;i<given.length();i++) {
	System.out.print(givenarray[i]);
}
}
public void upperandlowewrcaseconversation() {
	String given="i love my mother";
	given=given.toUpperCase();
	char[] givenarray=given.toCharArray();
	for(int i=0;i<given.length();i++) {
		if(givenarray[i]>=65&&givenarray[i]<=90){
		givenarray[i]=(char) ((char)	givenarray[i]+32);
		}
	}
	for(int i=0;i<given.length();i++) {
		System.out.println(givenarray[i]);
	}
}
	public static void primenumber() {
		int given=6;
		for(int i=2;i<=given;i++) {
			for(int j=2;j<=i;j++) {
				if(j==i) {
					System.out.println(i);
				}
			
			
					
				}
				
			}
			
		}
	public static void fibonacciseries() {
		System.out.println("enter your string");
		Scanner scanner=new Scanner(System.in);
		int num,a=0,b=0,c=1;
	int num1=	scanner.nextInt();
	for(int i=0;i<=num1;i++) {
		a=b;
		b=c;
		c=a+b;
		System.out.println(a);
		
	}
	
	}
		
	
	


	


	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
javapractice practice=new javapractice();
//practice.howtoreverseastring();
//practice.usingarraylist();
//practice.swapthenumbers();
//practice.reversethenumber();
//practice.triangularpattern();
//practice.findthelengthofthestring();
//practice.smallestnumber();
//practice.reverseawords();
//practice.elementpresentinthearray();
//practice.positionofanenglishalphabet();
//practice.findtheoccuranceofacharactewrfromastring();
//practice.removetheleadingandtrailingedge();
//practice.findthemissingalphabetinthegivenstring();
//practice.numberofvowelsinyourname();
//practice.extractnumbersfromastringandaddthem();
//practice.replacevowelswithasprecialcharacter();
//practice.upperandlowewrcaseconversation();
//practice.primenumber();
practice.fibonacciseries();

	}

}
