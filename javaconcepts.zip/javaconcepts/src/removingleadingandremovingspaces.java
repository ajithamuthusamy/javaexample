
public class removingleadingandremovingspaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name= "ajitha dhanya" ;
		//System.out.println(name.trim());
		System.out.println(name.replaceAll("^[\t]+|[\t]+$", ""));

	}

}
