import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class smallestnumber {
	 static Integer givenarray[]= {7,8,9,10,11};
	public static void small() {
	int smallest=	Integer.MAX_VALUE;
	for(int i=0;i<givenarray.length;i++) {
		if(givenarray[i]<smallest) {
			smallest=givenarray[i];
		}
		}
	System.out.println(smallest);
	
	}
	public static void usingarrays() {
		Arrays.sort(givenarray);
		System.out.println(givenarray[0]);
	}
	public static void usingcollections() {
		List<Integer> list=Arrays.asList(givenarray);
		Collections.sort(list);
		int smallest=list.get(0);
		System.out.println(smallest);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//small();
		//usingarrays();
		usingcollections();

	}

}
