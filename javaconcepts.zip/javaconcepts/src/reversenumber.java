import java.util.Scanner;

public  class reversenumber {
	
public static void reverse() {
	int givennumber=123;
	int reversednumber=0;
	while(givennumber!=0) {
		reversednumber=reversednumber*10;
		reversednumber=reversednumber+givennumber%10;
		givennumber=givennumber/10;
	}
	System.out.println(reversednumber);
	}
public static void usingscanner() {
	int givennumber=0;
	int reversednumber=0;
	System.out.println("Enter your number:");
	Scanner scanner=new Scanner(System.in);
	givennumber=scanner.nextInt();
	while(givennumber!=0) {
		reversednumber=reversednumber*10;
		reversednumber=reversednumber+givennumber%10;
		givennumber=givennumber/10;
	}
	System.out.println(reversednumber);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		reverse();
		usingscanner();

	}

}
