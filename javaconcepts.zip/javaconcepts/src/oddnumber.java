import java.util.ArrayList;
import java.util.List;

public class oddnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*for(int i=0;i<=100;i++) {
			if( i%2 !=0) {
		System.out.println("addnumber is:"+i);
		
	}

	}
		int number = 1;
		for(int i=0;i<=10;i++) {
			
		System.out.println("multiplication number is:"+number+"*"+i+"="+number*i);*/
		

		

	
		String name="ajitha";
		for(int i= name.length()-1;i>=0;i--) {
			System.out.println(name.charAt(i));
		}
	}
}
		
	
		/*StringBuffer name1=new StringBuffer("ajitha");
		System.out.println(name1.insert(0, "ajitha"));
	System.out.println(name1.reverse());
		
		
	}*/


