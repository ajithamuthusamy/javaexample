import java.util.Scanner;

public class lengthex {
	public static void length() {
		System.out.println("enter your name");
		Scanner scanner =new Scanner(System.in);
		String givenname;
	givenname=	scanner.next();
	int length=0;
	char[] characterarray=givenname.toCharArray();
	for (char c : characterarray) {
		length++;
		
	}
	System.out.println(length);
	
	}
@SuppressWarnings("null")
public static void length1() {
	System.out.println("enter your name");
	Scanner scanner =new Scanner(System.in);
	String givenname = null;
	givenname=scanner.next();
	System.out.println(givenname.length());

	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//length();
		length1();

	}

}
