
public class reversewords {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String given="i love dhanya";
		String reversed="";
		String[] temp=given.split(" ");
		for (int i=temp.length-1;i>=0;i--) {
			reversed=reversed+temp[i]+" ";
			
			
		}
		
System.out.println(reversed);
	}

}
