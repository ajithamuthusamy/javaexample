package javaconceptexample;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class dompropertiesexample {
	static Logger logger=Logger.getLogger(dompropertiesexample.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
DOMConfigurator.configure("log4jexample.xml");
logger.debug("this is a debug");
logger.info("this is an info message");
logger.warn("this is a warning message");
logger.error("this is an error message");
logger.fatal("this is a fetal");

	}

}
