
public class stringex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name= "dhanya karki" ;
	System.out.println(	name.replaceAll(" ", ""));
int count=1;
	int i=10;
	for(int j=2;j<=i;j++) {
		count++;
	}
	if(i%count==0)
	{
		System.out.println("prime number");
	}else {
		System.out.println("this is not prime number");
	}
		
	}

}
////////https://github.com/ajithamuthusamy/seleniumexample