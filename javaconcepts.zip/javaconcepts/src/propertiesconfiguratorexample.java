import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class propertiesconfiguratorexample {
	static Logger logger=Logger.getLogger(propertiesconfiguratorexample.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
PropertyConfigurator.configure("log.properties");
logger.debug("this is the debugmessage");
logger.info("this is the info message");
logger.warn("this is the warning message");
logger.error("this is the error");
logger.fatal("this is the fatal");

	}

}
